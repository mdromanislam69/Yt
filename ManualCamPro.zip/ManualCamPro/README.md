# ManualCam Pro - Android Manual Video Camera

A fully-featured manual video camera app for Android using the Camera2 API.

## Features

- **Manual Controls**: ISO, Shutter Speed, Focus, Exposure Compensation
- **White Balance**: Auto + 5 manual presets (Daylight, Cloudy, Shade, Tungsten, Fluorescent)
- **Video Quality**: 4K / 1080p / 720p switching
- **Pinch-to-Zoom**: Smooth digital zoom with zoom level display
- **Tap-to-Focus**: Touch anywhere on the preview to focus
- **Real-time metering**: Live ISO/shutter readout in Auto mode
- **Timer overlay**: Elapsed recording time HH:MM:SS
- **Front/back camera flip**
- **Videos saved** to DCIM/ManualCamPro on device

## How to Build

### Requirements
- Android Studio Hedgehog (2023.1.1) or newer
- Android SDK 34
- Java 8 or higher
- A physical Android device (API 24+) — Camera2 manual controls do NOT work on emulator

### Steps
1. Open **Android Studio**
2. Select **File → Open** and choose this `ManualCamPro` folder
3. Wait for Gradle sync to complete
4. Connect your Android device via USB and enable **Developer Mode + USB Debugging**
5. Click **Run ▶** or press `Shift+F10`

### Build APK (without a device)
```
./gradlew assembleDebug
```
Output APK: `app/build/outputs/apk/debug/app-debug.apk`

## App Screens

### Camera Screen (Landscape)
```
┌──────────────────────────────────────────┐
│ MANUAL CAM PRO  1.0x  00:00:00  ● 1080p  │  ← Top bar
├──────────┬──────────────────┬────────────┤
│ AE: ON   │                  │   [●]      │  ← Record btn
│          │   LIVE PREVIEW   │   [⟳]      │  ← Flip btn
│ ISO 100  │                  │   AWB      │
│ 1/60     │   (pinch zoom)   │   WB AUTO  │
│ EV 0     │   (tap focus)    │            │
│          │                  │            │
└──────────┴──────────────────┴────────────┘
```

## Manual Controls

| Control | Description |
|---------|-------------|
| **AE: ON/OFF** | Toggle auto/manual exposure |
| **ISO** | Sensor sensitivity (50–3200+) |
| **Shutter** | 1/4000s to 1s |
| **Focus** | Manual focus distance (near ↔ far) |
| **EV Comp** | Exposure compensation ±3 stops |
| **AWB** | Toggle auto white balance |
| **WB Preset** | Sun/Cloud/Shade/Tungsten/Fluorescent |
| **Quality** | 4K / 1080p / 720p |

## Permissions Required
- `CAMERA` — to access the camera
- `RECORD_AUDIO` — for audio in videos
- `WRITE_EXTERNAL_STORAGE` — for saving videos (Android ≤9)

## Technical Notes

- Uses **Camera2 API** for full manual sensor control
- H.264 video encoding with AAC audio
- Bitrates: 4K=50Mbps, 1080p=20Mbps, 720p=10Mbps
- MediaStore API for proper video file storage on Android 10+
- Supports hardware zoom ratio (Android 11+) with crop fallback for older versions

## Minimum Requirements
- Android 7.0 (API 24)
- Camera2 full/limited hardware level
