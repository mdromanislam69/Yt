package com.manualpro.camera

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.hardware.camera2.params.RggbChannelVector
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.manualpro.camera.databinding.FragmentCameraBinding
import kotlinx.coroutines.*
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

class CameraFragment : Fragment() {

    private var _binding: FragmentCameraBinding? = null
    private val binding get() = _binding!!

    // Camera2 components
    private lateinit var cameraManager: CameraManager
    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var captureRequestBuilder: CaptureRequest.Builder? = null
    private var mediaRecorder: MediaRecorder? = null

    // Background thread
    private var backgroundThread: HandlerThread? = null
    private var backgroundHandler: Handler? = null

    // Camera properties
    private var cameraId: String = ""
    private var videoSize: Size = Size(1920, 1080)
    private var previewSize: Size = Size(1920, 1080)
    private var characteristics: CameraCharacteristics? = null
    private var isRecording = false
    private var isFrontCamera = false

    // Manual control values
    private var currentIso = 100
    private var currentShutterSpeed = 1_000_000_000L / 60  // 1/60s in nanoseconds
    private var currentExposureComp = 0
    private var currentWhiteBalance = CaptureRequest.CONTROL_AWB_MODE_AUTO
    private var isAutoExposure = true
    private var isAutoFocus = true
    private var isAutoWhiteBalance = true
    private var currentFocusDistance = 0.0f
    private var currentZoom = 1.0f
    private var maxZoom = 1.0f

    // ISO range
    private var isoMin = 50
    private var isoMax = 3200

    // Shutter speed steps (in nanoseconds)
    private val shutterSpeeds = listOf(
        1_000_000_000L / 4000,   // 1/4000
        1_000_000_000L / 2000,   // 1/2000
        1_000_000_000L / 1000,   // 1/1000
        1_000_000_000L / 500,    // 1/500
        1_000_000_000L / 250,    // 1/250
        1_000_000_000L / 125,    // 1/125
        1_000_000_000L / 60,     // 1/60
        1_000_000_000L / 30,     // 1/30
        1_000_000_000L / 15,     // 1/15
        1_000_000_000L / 8,      // 1/8
        1_000_000_000L / 4,      // 1/4
        1_000_000_000L / 2,      // 1/2
        1_000_000_000L            // 1s
    )
    private val shutterLabels = listOf(
        "1/4000", "1/2000", "1/1000", "1/500", "1/250", "1/125",
        "1/60", "1/30", "1/15", "1/8", "1/4", "1/2", "1\""
    )
    private var shutterIndex = 6 // default 1/60

    // WB presets
    private val wbModes = listOf(
        CaptureRequest.CONTROL_AWB_MODE_AUTO,
        CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT,
        CaptureRequest.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT,
        CaptureRequest.CONTROL_AWB_MODE_SHADE,
        CaptureRequest.CONTROL_AWB_MODE_TUNGSTEN,
        CaptureRequest.CONTROL_AWB_MODE_FLUORESCENT
    )
    private val wbLabels = listOf("AUTO", "SUN", "CLOUD", "SHADE", "TUNGSTEN", "FLUOR")
    private var wbIndex = 0

    // Video quality
    private val videoQualities = listOf("4K", "1080p", "720p")
    private val videoSizes = listOf(Size(3840, 2160), Size(1920, 1080), Size(1280, 720))
    private var videoQualityIndex = 1

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCameraBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
        setupGestureListeners()
    }

    private fun setupUI() {
        // Record button
        binding.btnRecord.setOnClickListener {
            if (isRecording) stopRecording() else startRecording()
        }

        // Flip camera
        binding.btnFlipCamera.setOnClickListener {
            isFrontCamera = !isFrontCamera
            closeCamera()
            openCamera()
        }

        // Auto/Manual toggle for exposure
        binding.btnAutoExposure.setOnClickListener {
            isAutoExposure = !isAutoExposure
            isAutoFocus = isAutoExposure
            updateAutoExposureUI()
            updateCaptureSettings()
        }

        // Auto White Balance toggle
        binding.btnAutoWB.setOnClickListener {
            isAutoWhiteBalance = !isAutoWhiteBalance
            updateWBUI()
            updateCaptureSettings()
        }

        // ISO controls
        binding.btnIsoUp.setOnClickListener {
            currentIso = (currentIso * 1.25).toInt().coerceAtMost(isoMax)
            currentIso = snapToIsoStep(currentIso)
            updateManualControls()
        }
        binding.btnIsoDown.setOnClickListener {
            currentIso = (currentIso * 0.8).toInt().coerceAtLeast(isoMin)
            currentIso = snapToIsoStep(currentIso)
            updateManualControls()
        }

        // Shutter speed controls
        binding.btnShutterUp.setOnClickListener {
            if (shutterIndex > 0) {
                shutterIndex--
                currentShutterSpeed = shutterSpeeds[shutterIndex]
                updateManualControls()
            }
        }
        binding.btnShutterDown.setOnClickListener {
            if (shutterIndex < shutterSpeeds.size - 1) {
                shutterIndex++
                currentShutterSpeed = shutterSpeeds[shutterIndex]
                updateManualControls()
            }
        }

        // White balance presets
        binding.btnWbNext.setOnClickListener {
            wbIndex = (wbIndex + 1) % wbModes.size
            currentWhiteBalance = wbModes[wbIndex]
            updateWBUI()
            updateCaptureSettings()
        }

        // Exposure compensation
        binding.btnEvUp.setOnClickListener {
            if (currentExposureComp < 3) {
                currentExposureComp++
                updateManualControls()
            }
        }
        binding.btnEvDown.setOnClickListener {
            if (currentExposureComp > -3) {
                currentExposureComp--
                updateManualControls()
            }
        }

        // Focus controls
        binding.btnFocusFar.setOnClickListener {
            if (!isAutoFocus) {
                currentFocusDistance = (currentFocusDistance + 0.05f).coerceAtMost(1.0f)
                updateCaptureSettings()
                binding.tvFocusValue.text = "MF: ${(currentFocusDistance * 100).toInt()}%"
            }
        }
        binding.btnFocusNear.setOnClickListener {
            if (!isAutoFocus) {
                currentFocusDistance = (currentFocusDistance - 0.05f).coerceAtLeast(0.0f)
                updateCaptureSettings()
                binding.tvFocusValue.text = "MF: ${(currentFocusDistance * 100).toInt()}%"
            }
        }

        // Video quality
        binding.btnQuality.setOnClickListener {
            if (!isRecording) {
                videoQualityIndex = (videoQualityIndex + 1) % videoQualities.size
                videoSize = videoSizes[videoQualityIndex]
                binding.btnQuality.text = videoQualities[videoQualityIndex]
                restartSession()
            }
        }

        updateAutoExposureUI()
        updateWBUI()
        updateManualControls()
    }

    private fun setupGestureListeners() {
        // Tap to focus on preview
        binding.textureView.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP && isAutoFocus) {
                triggerTapToFocus(event.x, event.y)
            }
            // Pinch to zoom
            true
        }

        val scaleGestureDetector = ScaleGestureDetector(requireContext(),
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(detector: ScaleGestureDetector): Boolean {
                    currentZoom = (currentZoom * detector.scaleFactor).coerceIn(1.0f, maxZoom)
                    applyZoom()
                    binding.tvZoomLevel.text = "%.1fx".format(currentZoom)
                    return true
                }
            })

        binding.textureView.setOnTouchListener { v, event ->
            scaleGestureDetector.onTouchEvent(event)
            if (event.action == MotionEvent.ACTION_UP && !scaleGestureDetector.isInProgress) {
                if (isAutoFocus) triggerTapToFocus(event.x, event.y)
            }
            true
        }
    }

    private fun snapToIsoStep(iso: Int): Int {
        val steps = listOf(50, 64, 80, 100, 125, 160, 200, 250, 320, 400, 500, 640, 800, 1000, 1250, 1600, 2000, 2500, 3200)
        return steps.minByOrNull { Math.abs(it - iso) } ?: iso
    }

    private fun updateAutoExposureUI() {
        if (isAutoExposure) {
            binding.btnAutoExposure.text = "AE: ON"
            binding.btnAutoExposure.alpha = 1.0f
            binding.manualExposurePanel.visibility = View.GONE
            binding.tvFocusValue.text = "AF"
        } else {
            binding.btnAutoExposure.text = "AE: OFF"
            binding.btnAutoExposure.alpha = 0.7f
            binding.manualExposurePanel.visibility = View.VISIBLE
            binding.tvFocusValue.text = "MF: ${(currentFocusDistance * 100).toInt()}%"
        }
    }

    private fun updateWBUI() {
        if (isAutoWhiteBalance) {
            binding.btnAutoWB.text = "AWB"
            binding.btnAutoWB.alpha = 1.0f
            binding.tvWbValue.text = "AWB"
        } else {
            binding.btnAutoWB.text = "WB"
            binding.btnAutoWB.alpha = 0.7f
            binding.tvWbValue.text = wbLabels[wbIndex]
        }
    }

    private fun updateManualControls() {
        binding.tvIsoValue.text = "ISO $currentIso"
        binding.tvShutterValue.text = shutterLabels[shutterIndex]
        binding.tvEvValue.text = if (currentExposureComp >= 0) "EV+$currentExposureComp" else "EV$currentExposureComp"
        if (!isAutoExposure) updateCaptureSettings()
    }

    private fun triggerTapToFocus(x: Float, y: Float) {
        val builder = captureRequestBuilder ?: return
        val session = captureSession ?: return

        // Show focus indicator
        binding.focusIndicator.apply {
            translationX = x - width / 2f
            translationY = y - height / 2f
            visibility = View.VISIBLE
            alpha = 1f
            animate().alpha(0f).setDuration(1000).withEndAction {
                visibility = View.GONE
            }.start()
        }

        // Trigger AF
        builder.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_START)
        session.capture(builder.build(), null, backgroundHandler)
        builder.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_IDLE)
    }

    // ==================== Camera2 Lifecycle ====================

    override fun onResume() {
        super.onResume()
        startBackgroundThread()
        if (binding.textureView.isAvailable) {
            openCamera()
        } else {
            binding.textureView.surfaceTextureListener = surfaceTextureListener
        }
    }

    override fun onPause() {
        if (isRecording) stopRecording()
        closeCamera()
        stopBackgroundThread()
        super.onPause()
    }

    private val surfaceTextureListener = object : TextureView.SurfaceTextureListener {
        override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
            openCamera()
        }
        override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}
        override fun onSurfaceTextureDestroyed(surface: SurfaceTexture) = true
        override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
    }

    private fun startBackgroundThread() {
        backgroundThread = HandlerThread("CameraBackground").also { it.start() }
        backgroundHandler = Handler(backgroundThread!!.looper)
    }

    private fun stopBackgroundThread() {
        backgroundThread?.quitSafely()
        try {
            backgroundThread?.join()
            backgroundThread = null
            backgroundHandler = null
        } catch (e: InterruptedException) {
            e.printStackTrace()
        }
    }

    @SuppressLint("MissingPermission")
    private fun openCamera() {
        cameraManager = requireContext().getSystemService(Context.CAMERA_SERVICE) as CameraManager
        cameraId = getCameraId()
        characteristics = cameraManager.getCameraCharacteristics(cameraId)

        // Get camera capabilities
        characteristics?.let { chars ->
            val isoRange = chars.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
            isoRange?.let {
                isoMin = it.lower
                isoMax = it.upper
                currentIso = currentIso.coerceIn(isoMin, isoMax)
            }
            val zoomRatio = chars.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM)
            maxZoom = zoomRatio ?: 1.0f

            // Find best supported video size
            val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val supportedSizes = map?.getOutputSizes(MediaRecorder::class.java)
            videoSize = getBestVideoSize(supportedSizes, videoSizes[videoQualityIndex])
            previewSize = videoSize
        }

        try {
            cameraManager.openCamera(cameraId, cameraStateCallback, backgroundHandler)
        } catch (e: CameraAccessException) {
            e.printStackTrace()
        }
    }

    private fun getCameraId(): String {
        for (id in cameraManager.cameraIdList) {
            val facing = cameraManager.getCameraCharacteristics(id)
                .get(CameraCharacteristics.LENS_FACING)
            if (isFrontCamera && facing == CameraCharacteristics.LENS_FACING_FRONT) return id
            if (!isFrontCamera && facing == CameraCharacteristics.LENS_FACING_BACK) return id
        }
        return cameraManager.cameraIdList[0]
    }

    private fun getBestVideoSize(supported: Array<Size>?, desired: Size): Size {
        if (supported == null) return desired
        // Exact match
        supported.find { it == desired }?.let { return it }
        // Closest match with same aspect ratio
        val targetAspect = desired.width.toFloat() / desired.height
        return supported
            .filter { (it.width.toFloat() / it.height - targetAspect) < 0.1f }
            .minByOrNull { Math.abs(it.width * it.height - desired.width * desired.height) }
            ?: supported.maxByOrNull { it.width * it.height }
            ?: desired
    }

    private val cameraStateCallback = object : CameraDevice.StateCallback() {
        override fun onOpened(camera: CameraDevice) {
            cameraDevice = camera
            createPreviewSession()
        }
        override fun onDisconnected(camera: CameraDevice) {
            camera.close()
            cameraDevice = null
        }
        override fun onError(camera: CameraDevice, error: Int) {
            camera.close()
            cameraDevice = null
            activity?.runOnUiThread {
                Toast.makeText(requireContext(), "Camera error: $error", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun createPreviewSession() {
        val texture = binding.textureView.surfaceTexture ?: return
        texture.setDefaultBufferSize(previewSize.width, previewSize.height)
        val previewSurface = Surface(texture)

        captureRequestBuilder = cameraDevice?.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
        captureRequestBuilder?.addTarget(previewSurface)

        cameraDevice?.createCaptureSession(
            listOf(previewSurface),
            object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(session: CameraCaptureSession) {
                    captureSession = session
                    applyInitialSettings()
                }
                override fun onConfigureFailed(session: CameraCaptureSession) {
                    activity?.runOnUiThread {
                        Toast.makeText(requireContext(), "Preview failed", Toast.LENGTH_SHORT).show()
                    }
                }
            },
            backgroundHandler
        )
    }

    private fun applyInitialSettings() {
        updateCaptureSettings()
        activity?.runOnUiThread {
            binding.tvZoomLevel.text = "1.0x"
            binding.btnQuality.text = videoQualities[videoQualityIndex]
        }
    }

    private fun updateCaptureSettings() {
        val builder = captureRequestBuilder ?: return
        val session = captureSession ?: return

        if (isAutoExposure) {
            builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
            builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO)
            builder.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, currentExposureComp)
        } else {
            builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
            builder.set(CaptureRequest.SENSOR_SENSITIVITY, currentIso)
            builder.set(CaptureRequest.SENSOR_EXPOSURE_TIME, currentShutterSpeed)
            builder.set(CaptureRequest.LENS_FOCUS_DISTANCE, currentFocusDistance)
        }

        if (isAutoWhiteBalance) {
            builder.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO)
        } else {
            builder.set(CaptureRequest.CONTROL_AWB_MODE, currentWhiteBalance)
        }

        try {
            session.setRepeatingRequest(builder.build(), captureCallback, backgroundHandler)
        } catch (e: CameraAccessException) {
            e.printStackTrace()
        }
    }

    private val captureCallback = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(
            session: CameraCaptureSession,
            request: CaptureRequest,
            result: TotalCaptureResult
        ) {
            // Update real-time exposure info when in auto mode
            if (isAutoExposure) {
                val iso = result.get(CaptureResult.SENSOR_SENSITIVITY) ?: return
                val exposureTime = result.get(CaptureResult.SENSOR_EXPOSURE_TIME) ?: return
                val shutterLabel = formatShutterSpeed(exposureTime)
                activity?.runOnUiThread {
                    binding.tvIsoValue.text = "ISO $iso"
                    binding.tvShutterValue.text = shutterLabel
                }
            }
        }
    }

    private fun formatShutterSpeed(ns: Long): String {
        return when {
            ns < 1_000_000 -> "1/${(1_000_000_000.0 / ns).roundToInt()}"
            ns < 500_000_000 -> "1/${(1_000_000_000.0 / ns).roundToInt()}"
            ns < 1_500_000_000 -> "1\""
            else -> "${ns / 1_000_000_000.0}s"
        }
    }

    private fun applyZoom() {
        val builder = captureRequestBuilder ?: return
        val chars = characteristics ?: return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            builder.set(CaptureRequest.CONTROL_ZOOM_RATIO, currentZoom)
        } else {
            val sensorRect = chars.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)!!
            val cropW = (sensorRect.width() / currentZoom).toInt()
            val cropH = (sensorRect.height() / currentZoom).toInt()
            val cropX = (sensorRect.width() - cropW) / 2
            val cropY = (sensorRect.height() - cropH) / 2
            val cropRect = android.graphics.Rect(cropX, cropY, cropX + cropW, cropY + cropH)
            builder.set(CaptureRequest.SCALER_CROP_REGION, cropRect)
        }

        try {
            captureSession?.setRepeatingRequest(builder.build(), captureCallback, backgroundHandler)
        } catch (e: CameraAccessException) {
            e.printStackTrace()
        }
    }

    private fun closeCamera() {
        captureSession?.close()
        captureSession = null
        cameraDevice?.close()
        cameraDevice = null
        mediaRecorder?.release()
        mediaRecorder = null
    }

    private fun restartSession() {
        closeCamera()
        openCamera()
    }

    // ==================== Video Recording ====================

    private fun startRecording() {
        val camera = cameraDevice ?: return
        val texture = binding.textureView.surfaceTexture ?: return

        setupMediaRecorder()
        val recorderSurface = mediaRecorder?.surface ?: return

        texture.setDefaultBufferSize(previewSize.width, previewSize.height)
        val previewSurface = Surface(texture)

        captureRequestBuilder = camera.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
        captureRequestBuilder?.addTarget(previewSurface)
        captureRequestBuilder?.addTarget(recorderSurface)

        camera.createCaptureSession(
            listOf(previewSurface, recorderSurface),
            object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(session: CameraCaptureSession) {
                    captureSession = session
                    updateCaptureSettings()
                    mediaRecorder?.start()
                    isRecording = true
                    activity?.runOnUiThread {
                        binding.btnRecord.setImageResource(R.drawable.ic_stop)
                        binding.recordingIndicator.visibility = View.VISIBLE
                        startRecordingTimer()
                    }
                }
                override fun onConfigureFailed(session: CameraCaptureSession) {
                    activity?.runOnUiThread {
                        Toast.makeText(requireContext(), "Recording setup failed", Toast.LENGTH_SHORT).show()
                    }
                }
            },
            backgroundHandler
        )
    }

    private fun setupMediaRecorder() {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fileName = "ManualCam_$timestamp.mp4"

        mediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(requireContext())
        } else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }

        val contentValues = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "DCIM/ManualCamPro")
        }

        val videoUri = requireContext().contentResolver.insert(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI, contentValues
        )

        mediaRecorder?.apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setVideoSource(MediaRecorder.VideoSource.SURFACE)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setOutputFile(requireContext().contentResolver.openFileDescriptor(videoUri!!, "w")!!.fileDescriptor)
            setVideoEncodingBitRate(getBitrate())
            setVideoFrameRate(30)
            setVideoSize(videoSize.width, videoSize.height)
            setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setAudioSamplingRate(44100)
            setAudioEncodingBitRate(128000)
            setOrientationHint(0)
            try {
                prepare()
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
    }

    private fun getBitrate(): Int {
        return when (videoQualityIndex) {
            0 -> 50_000_000  // 4K: 50 Mbps
            1 -> 20_000_000  // 1080p: 20 Mbps
            2 -> 10_000_000  // 720p: 10 Mbps
            else -> 20_000_000
        }
    }

    private var recordingSeconds = 0
    private var timerJob: Job? = null

    private fun startRecordingTimer() {
        recordingSeconds = 0
        timerJob = CoroutineScope(Dispatchers.Main).launch {
            while (isRecording) {
                val h = recordingSeconds / 3600
                val m = (recordingSeconds % 3600) / 60
                val s = recordingSeconds % 60
                binding.tvRecordingTime.text = "%02d:%02d:%02d".format(h, m, s)
                delay(1000)
                recordingSeconds++
            }
        }
    }

    private fun stopRecording() {
        timerJob?.cancel()
        isRecording = false

        try {
            captureSession?.stopRepeating()
            captureSession?.abortCaptures()
        } catch (e: CameraAccessException) {
            e.printStackTrace()
        }

        try {
            mediaRecorder?.stop()
        } catch (e: RuntimeException) {
            e.printStackTrace()
        }
        mediaRecorder?.reset()

        activity?.runOnUiThread {
            binding.btnRecord.setImageResource(R.drawable.ic_record)
            binding.recordingIndicator.visibility = View.GONE
            binding.tvRecordingTime.text = "00:00:00"
            Toast.makeText(requireContext(), "Video saved to DCIM/ManualCamPro", Toast.LENGTH_SHORT).show()
        }

        createPreviewSession()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
